import { Redirect } from "expo-router";

const Root = () => {
  return <Redirect href="/home" />;
};

export default Root;

